package Tree;

public class GenericTreeNode<E>
{
    public E value;
}
